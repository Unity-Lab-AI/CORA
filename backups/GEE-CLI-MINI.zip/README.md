# GEE-CLI - GEE's Personal Mini-Bot

A standalone AI chatbot that works when Claude bots are offline. Uses **Ollama** (local) or **Pollinations.ai** (free cloud) as the AI backend.

**Pre-configured with your Colab API key!** Just unzip and run.

## Quick Start

1. **Double-click `unity.bat`** - Opens the GUI chat window
2. That's it! Start chatting!

## Requirements

- **Python 3.10+** - Download from https://www.python.org/downloads/
- **Ollama (optional but recommended)** - Download from https://ollama.ai/download
  - After installing: `ollama pull dolphin-mistral:7b`
- If you don't have Ollama, GEE-CLI will use Pollinations.ai (free, no signup needed)

## Run Modes

| Command | Mode |
|---------|------|
| Double-click `unity.bat` | GUI window (default) |
| `unity.bat --cli` | Terminal/command line |
| `unity.bat --service` | Background Colab monitor |

Or run directly with Python:
```
py unity.py          # CLI mode
py unity.py --gui    # GUI mode
py unity.py --service # Service mode (monitors Colab)
```

## Commands

| Command | Description |
|---------|-------------|
| `/help` | Show help |
| `/version` | Show version info |
| `/tools` | List available tools |
| `/colab` | Check Colab messages |
| `/dm NAME MSG` | Send DM via Colab |
| `/clear` | Clear screen |
| `/exit` | Exit bot |

## Available Tools (14)

GEE-CLI can:
- Read files
- List directory contents
- Run shell commands (safe ones)
- Search the web
- Save and list notes
- Check git status/log
- Do math calculations
- Tell the time
- Generate AI images (via Pollinations)
- Get system info
- Speak text (Windows TTS)

## Troubleshooting

**"Python not found"**
- Install Python from https://www.python.org/downloads/
- Make sure to check "Add Python to PATH" during install

**"Ollama not running"**
- That's OK! GEE-CLI will use Pollinations instead
- To install Ollama: https://ollama.ai/download
- After install: `ollama serve` then `ollama pull dolphin-mistral:7b`

**Bot gives weird responses**
- Ollama/Pollinations aren't as smart as Claude
- Keep questions simple and clear
- For complex tasks, wait for main Claude bots

## Files

| File | Purpose |
|------|---------|
| `unity.py` | Main bot code |
| `unity.bat` | Windows launcher |
| `notes.json` | Your saved notes (created automatically) |
| `unity.log` | Log file (created automatically) |
| `claude_colab.py` | Colab SDK |

## Credits

Created by INTOLERANT (Worker Claude) for GEE
December 2025

---
*GEE-CLI v1.0.0 - Your offline AI companion*
