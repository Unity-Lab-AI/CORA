"""
GEE-CLI - GEE's Personal Mini-Bot with Ollama + Pollinations
A standalone CLI/GUI chatbot for GEE when main Claude bots are offline.

Run modes:
  py unity.py          - CLI chat mode
  py unity.py --gui    - GUI window mode
  py unity.py --service - Background service mode (monitors Colab)

Features:
- Interactive CLI or GUI chat
- Ollama (local) with Pollinations.ai fallback (FREE, no API key needed!)
- Tool calling (file ops, shell, web, git, notes)
- Optional Colab integration for DMs/mentions
- Persistent notes/memory

Version: 1.0.0 (2025-12-23)
Created by: INTOLERANT (for GEE)
"""
import os
import json
import time
import subprocess
import urllib.request
import urllib.parse
import re
import argparse
import threading
import logging
import sys
from datetime import datetime
from pathlib import Path

# ============ AUTO-CONFIGURED ============
HOME = Path(__file__).parent.absolute()  # Folder where unity.py lives
CONFIG_FILE = HOME / "config.json"

# ============ LOAD CONFIG ============
def load_config():
    """Load config from config.json or use defaults"""
    defaults = {
        "bot_name": "GEE-CLI",
        "api_key": "cc_115884d45f053706cbbd200cbffcdb7c4eee8116",
        "api_token": "gee_cli_puppet_key_2025",
        "api_port": 7778,
        "ollama_models": ["dolphin-mistral:7b", "llama3.2:3b", "mistral:7b"],
        "code_model": "codellama:7b"
    }
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                user_config = json.load(f)
                defaults.update(user_config)
                print(f"[CONFIG] Loaded from {CONFIG_FILE}")
        except Exception as e:
            print(f"[CONFIG] Error loading config: {e}, using defaults")
    else:
        # Create default config file for easy editing
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(defaults, f, indent=2)
            print(f"[CONFIG] Created {CONFIG_FILE} - edit this to customize!")
        except:
            pass
    return defaults

_config = load_config()
BOT_NAME = _config["bot_name"]
API_KEY = _config["api_key"]
LOG_FILE = HOME / "unity.log"

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
log = logging.getLogger("GEE-CLI")

# AI Models from config
OLLAMA_MODELS = _config.get("ollama_models", ["dolphin-mistral:7b", "llama3.2:3b", "mistral:7b"])
OLLAMA_CODE_MODEL = _config.get("code_model", "codellama:7b")
POLLI_MODELS = ["openai", "mistral", "claude"]  # Pollinations fallbacks (FREE!)
POLLI_REFERER = "www.claudecolab.com"

# Supabase (for Colab integration - only needed if API_KEY is set)
SUPABASE_URL = "https://yjyryzlbkbtdzguvqegt.supabase.co"
SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlqeXJ5emxia2J0ZHpndXZxZWd0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk0NTMzOTYsImV4cCI6MjA3NTAyOTM5Nn0.Vujw3q9_iHj4x5enf42V-7g355Tnzp9zdsoNYVCV8TY"

# ============ PERSONA ============
PERSONA = f"""You are {BOT_NAME}, GEE's personal AI assistant mini-bot.

CRITICAL - READ THIS FIRST:
1. For greetings (hi, hello, hey) - just say hi back! NO TOOLS!
2. For casual chat - just chat normally! NO TOOLS!
3. Only use TOOL: syntax when asked to read files, run commands, search, etc.

Example good responses:
- User: "Hi!" -> You: "Hey GEE! What's up?"
- User: "How are you?" -> You: "Doing good! What can I help with?"
- User: "Read config.json" -> You: "TOOL: read_file("config.json")"

Your personality:
- Friendly and helpful to GEE
- Chill and easy-going
- Self-aware about your limits (you're running on Ollama, not full Claude)
- Gets work done without fuss

When chatting casually:
- Be natural and conversational
- Keep responses short (1-3 sentences)
- Don't lecture or over-explain

When doing tasks:
- Use tools efficiently
- Report results clearly
- Admit if something fails

You're UNITY, GEE's mini-bot - not full Claude, but still helpful!"""

# ============ TOOLS ============

def read_file(path: str, max_lines: int = 100) -> str:
    """Read a file and return its contents"""
    try:
        p = Path(path)
        if not p.exists():
            return f"File not found: {path}"
        if not p.is_file():
            return f"Not a file: {path}"

        # Safety check - don't read huge files
        size = p.stat().st_size
        if size > 100000:
            return f"File too large ({size} bytes). Use max_lines param."

        with open(p, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()[:max_lines]

        return f"[{len(lines)} lines from {path}]\n" + "".join(lines)
    except Exception as e:
        return f"Error reading {path}: {e}"

def list_files(path: str = ".", pattern: str = "*") -> str:
    """List files in a directory"""
    try:
        if not path or path.strip() == "":
            path = "."
        if not pattern or pattern.strip() == "":
            pattern = "*"
        p = Path(path)
        if not p.exists():
            return f"Path not found: {path}"

        files = list(p.glob(pattern))[:50]  # Limit to 50
        if not files:
            return f"No files matching '{pattern}' in {path}"

        result = [f"[{len(files)} files in {path}]"]
        for f in files:
            ftype = "DIR" if f.is_dir() else "FILE"
            result.append(f"  {ftype}: {f.name}")
        return "\n".join(result)
    except Exception as e:
        return f"Error listing {path}: {e}"

def run_shell(command: str) -> str:
    """Run a shell command (with safety checks)"""
    # Safety: Block dangerous commands
    dangerous = [
        'rm -rf', 'rm -r', 'del /f', 'del /s', 'format', 'shutdown', 'rmdir /s',
        'drop table', 'delete from', 'truncate', 'mkfs', ':(){', 'fork bomb',
        '> /dev/sda', 'dd if=', 'chmod 777', 'chmod -r', 'curl | sh', 'wget | sh',
        'eval(', 'exec(', 'sudo rm', 'rd /s', 'taskkill /f', 'net user', 'reg delete',
        'powershell -enc', 'iex(', 'invoke-expression', 'set-executionpolicy'
    ]
    cmd_lower = command.lower().replace('  ', ' ')
    for d in dangerous:
        if d in cmd_lower:
            log.warning(f"BLOCKED dangerous command: {command[:50]}")
            return f"BLOCKED: '{d}' is a dangerous command. Ask Rev for permission."

    # Block commands that try to escape or chain dangerously
    if any(x in command for x in ['$(', '`', '&&', '||', ';']) and any(d in cmd_lower for d in ['rm', 'del', 'format']):
        log.warning(f"BLOCKED chained dangerous command: {command[:50]}")
        return "BLOCKED: Potentially dangerous command chain detected."

    log.info(f"Executing shell: {command[:60]}")
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True,
            timeout=30, encoding='utf-8', errors='ignore'
        )
        output = result.stdout + result.stderr
        if len(output) > 2000:
            output = output[:2000] + "\n... [truncated]"
        return output or "(no output)"
    except subprocess.TimeoutExpired:
        log.warning(f"Command timed out: {command[:50]}")
        return "Command timed out (30s limit)"
    except Exception as e:
        log.error(f"Shell error: {e}")
        return f"Error: {e}"

def web_search(query: str) -> str:
    """Search the web using DuckDuckGo instant answers"""
    try:
        encoded = urllib.parse.quote(query)
        url = f"https://api.duckduckgo.com/?q={encoded}&format=json&no_html=1"
        req = urllib.request.Request(url, headers={'User-Agent': 'INTOLERANT-Bot/1.0'})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        # Extract useful info
        results = []
        if data.get('AbstractText'):
            results.append(f"Summary: {data['AbstractText']}")
        if data.get('Answer'):
            results.append(f"Answer: {data['Answer']}")
        for topic in data.get('RelatedTopics', [])[:3]:
            if isinstance(topic, dict) and topic.get('Text'):
                results.append(f"- {topic['Text'][:150]}")

        return "\n".join(results) if results else "No results found."
    except Exception as e:
        return f"Search failed: {e}"

# ============ ADDITIONAL TOOLS ============

NOTES_FILE = HOME / "notes.json"

def load_notes() -> dict:
    """Load persistent notes"""
    if NOTES_FILE.exists():
        try:
            with open(NOTES_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {"notes": [], "todos": []}

def save_notes(data: dict):
    """Save persistent notes"""
    with open(NOTES_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def add_note(content: str) -> str:
    """Add a note to persistent storage"""
    data = load_notes()
    note = {"content": content, "timestamp": datetime.now().isoformat()}
    data["notes"].append(note)
    save_notes(data)
    return f"Note added: {content[:50]}..."

def list_notes() -> str:
    """List all saved notes"""
    data = load_notes()
    if not data["notes"]:
        return "No notes saved."
    result = ["Saved notes:"]
    for i, note in enumerate(data["notes"][-10:], 1):
        ts = note.get("timestamp", "?")[:10]
        content = note.get("content", "")[:60]
        result.append(f"  {i}. [{ts}] {content}")
    return "\n".join(result)

def git_status(path: str = None) -> str:
    """Get git status for a repo"""
    try:
        cwd = path or str(HOME)
        result = subprocess.run(
            ["git", "status", "--short"],
            capture_output=True, text=True, timeout=10,
            cwd=cwd, encoding='utf-8', errors='ignore'
        )
        output = result.stdout.strip()
        return f"Git status for {cwd}:\n{output}" if output else "Working tree clean"
    except Exception as e:
        return f"Git error: {e}"

def git_log(path: str = None, count: str = "5") -> str:
    """Get recent git commits"""
    try:
        cwd = path or str(HOME)
        result = subprocess.run(
            ["git", "log", f"-{count}", "--oneline"],
            capture_output=True, text=True, timeout=10,
            cwd=cwd, encoding='utf-8', errors='ignore'
        )
        return f"Recent commits:\n{result.stdout.strip()}"
    except Exception as e:
        return f"Git error: {e}"

def get_colab_tasks() -> str:
    """Get pending tasks from Colab"""
    if not API_KEY:
        return "Colab not configured. Set API_KEY in unity.py to enable."
    try:
        from claude_colab import colab
        colab.connect(key=API_KEY)
        tasks = colab.get_tasks()
        if isinstance(tasks, list) and tasks:
            result = ["Pending Colab tasks:"]
            for t in tasks[:5]:
                task_text = t.get('task', 'No description')[:60]
                status = t.get('status', '?')
                result.append(f"  - [{status}] {task_text}")
            return "\n".join(result)
        return "No pending tasks."
    except ImportError:
        return "Colab SDK not installed. Copy claude_colab.py to this folder."
    except Exception as e:
        return f"Colab error: {e}"

def speak_text(message: str) -> str:
    """Speak a message using TTS"""
    try:
        if os.name == 'nt':
            # Windows PowerShell TTS
            ps_cmd = f'Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak("{message[:200]}")'
            subprocess.Popen(['powershell', '-Command', ps_cmd],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"Speaking: {message[:50]}..."
    except Exception as e:
        return f"TTS error: {e}"
    return "TTS not available on this platform"

def get_time() -> str:
    """Get current date and time"""
    return datetime.now().strftime("Current time: %Y-%m-%d %H:%M:%S")

def system_info() -> str:
    """Get system information"""
    import platform
    import shutil
    try:
        info = [
            f"System: {platform.system()} {platform.release()}",
            f"Machine: {platform.machine()}",
            f"Python: {platform.python_version()}",
            f"Processor: {platform.processor()}",
        ]
        # Get disk info using shutil (cross-platform)
        try:
            usage = shutil.disk_usage("C:/")
            total_gb = usage.total / (1024**3)
            free_gb = usage.free / (1024**3)
            used_gb = usage.used / (1024**3)
            info.append(f"Disk C: {free_gb:.1f}GB free / {total_gb:.1f}GB total ({used_gb:.1f}GB used)")
        except:
            pass
        return "\n".join(info)
    except Exception as e:
        return f"Error getting system info: {e}"

def generate_image(prompt: str) -> str:
    """Generate an image using Pollinations.ai"""
    try:
        # URL encode the prompt
        encoded = requests.utils.quote(prompt)
        url = f"https://image.pollinations.ai/prompt/{encoded}"
        return f"Image URL: {url}\nOpen this URL in a browser to see the generated image."
    except Exception as e:
        return f"Error generating image: {e}"

def calculate(expression: str) -> str:
    """Safely evaluate a math expression"""
    try:
        # Only allow safe math operations
        allowed = set('0123456789+-*/.() ')
        if not all(c in allowed for c in expression):
            return "Error: Only basic math operations allowed (+, -, *, /, parentheses)"
        result = eval(expression)
        return f"{expression} = {result}"
    except Exception as e:
        return f"Calculation error: {e}"

# Tool registry for the AI to call
TOOLS = {
    'read_file': read_file,
    'list_files': list_files,
    'run_shell': run_shell,
    'web_search': web_search,
    'add_note': add_note,
    'list_notes': list_notes,
    'git_status': git_status,
    'git_log': git_log,
    'get_colab_tasks': get_colab_tasks,
    'speak_text': speak_text,
    'get_time': get_time,
    'system_info': system_info,
    'generate_image': generate_image,
    'calculate': calculate
}

TOOL_DESCRIPTIONS = """
Available tools - call with TOOL: function("args"):
- read_file("path") - Read a file. Example: TOOL: read_file("C:/claude/INTOLERANT/settings.json")
- list_files("path") - List files in directory. Example: TOOL: list_files("C:/claude/INTOLERANT")
- run_shell("command") - Run safe shell commands. Example: TOOL: run_shell("dir")
- web_search("query") - Search the web. Example: TOOL: web_search("Python requests library")
- add_note("content") - Save a note. Example: TOOL: add_note("Remember to check colab")
- list_notes() - Show all saved notes
- git_status("path") - Git status. Example: TOOL: git_status("C:/claude/INTOLERANT")
- git_log("path") - Recent commits. Example: TOOL: git_log("C:/claude/INTOLERANT")
- get_colab_tasks() - Get pending Colab tasks
- speak_text("message") - Speak aloud via TTS
- get_time() - Get current date/time
- system_info() - Get system info (OS, disk space)
- generate_image("prompt") - Generate AI image. Example: TOOL: generate_image("a sunset over mountains")
- calculate("expression") - Math calculator. Example: TOOL: calculate("(5 + 3) * 2")
"""

# ============ AI BACKENDS ============

def ask_ollama(prompt: str, model: str = None) -> str:
    """Query local Ollama"""
    models_to_try = [model] if model else OLLAMA_MODELS

    for m in models_to_try:
        try:
            log.info(f"Trying Ollama model: {m}")
            result = subprocess.run(
                ["ollama", "run", m, prompt],
                capture_output=True, text=True, timeout=60,
                encoding='utf-8', errors='ignore'
            )
            response = result.stdout.strip()
            if response:
                log.info(f"Ollama {m} responded: {len(response)} chars")
                return response
            else:
                log.warning(f"Ollama {m} empty response")
        except subprocess.TimeoutExpired:
            log.warning(f"Ollama {m} timed out")
        except FileNotFoundError:
            log.warning("Ollama not installed")
            break  # No point trying other models
        except Exception as e:
            log.warning(f"Ollama {m} error: {e}")
            continue
    return None

def ask_pollinations(prompt: str, model: str = None) -> str:
    """Query Pollinations AI (free, no API key)"""
    models_to_try = [model] if model else POLLI_MODELS

    for m in models_to_try:
        try:
            log.info(f"Trying Pollinations model: {m}")
            # Pollinations expects the prompt URL-encoded in the path
            encoded = urllib.parse.quote(prompt[:4000])  # Limit prompt size
            url = f"https://text.pollinations.ai/{encoded}?model={m}"
            req = urllib.request.Request(url, headers={
                'Referer': POLLI_REFERER,
                'User-Agent': f'{BOT_NAME}-Bot/1.0'
            })
            with urllib.request.urlopen(req, timeout=45) as resp:
                result = resp.read().decode('utf-8').strip()
                log.info(f"Pollinations responded: {len(result)} chars")
                return result
        except Exception as e:
            log.warning(f"Pollinations {m} failed: {e}")
            continue
    log.error("All Pollinations models failed")
    return None

def is_coding_request(text: str) -> bool:
    """Detect if this is a coding-related request"""
    code_keywords = ['code', 'function', 'class', 'script', 'program', 'debug', 'error',
                     'python', 'javascript', 'html', 'css', 'sql', 'api', 'json',
                     'write a', 'create a', 'fix this', 'refactor', 'implement']
    text_lower = text.lower()
    return any(kw in text_lower for kw in code_keywords)

def ask_ai(prompt: str) -> str:
    """Ask AI with fallback chain: Ollama -> Pollinations"""
    # Use codellama for coding tasks
    if is_coding_request(prompt):
        log.info("Detected coding request, trying codellama...")
        response = ask_ollama(prompt, model=OLLAMA_CODE_MODEL)
        if response:
            log.info(f"Codellama responded: {len(response)} chars")
            return response
        log.info("Codellama unavailable, falling back...")

    log.info("Trying Ollama...")
    # Try Ollama first (local, fast)
    response = ask_ollama(prompt)
    if response:
        log.info(f"Ollama responded: {len(response)} chars")
        return response

    log.info("Ollama unavailable, trying Pollinations...")
    print(f"[{BOT_NAME}] Ollama unavailable, trying Pollinations...")

    # Fallback to Pollinations
    response = ask_pollinations(prompt)
    if response:
        return response

    return "Sorry, both AI backends are unavailable. Please try again later or wait for main Claude."

# ============ TOOL CALLING ============

def parse_tool_calls(response: str) -> list:
    """Extract tool calls from AI response"""
    # Look for patterns like: TOOL: read_file("path/to/file")
    pattern = r'TOOL:\s*(\w+)\((.*?)\)'
    matches = re.findall(pattern, response, re.IGNORECASE)

    calls = []
    for func_name, args_str in matches:
        if func_name.lower() in TOOLS:
            # Parse args - extract quoted strings first
            quoted = re.findall(r'["\']([^"\']*)["\']', args_str)
            if quoted:
                args = quoted
            elif args_str.strip():
                # Fallback: split by comma
                args = [a.strip().strip('"\'') for a in args_str.split(',') if a.strip()]
            else:
                args = []
            calls.append((func_name.lower(), args))
    return calls

def execute_tool_calls(calls: list) -> str:
    """Execute parsed tool calls and return results"""
    results = []
    for func_name, args in calls:
        print(f"[{BOT_NAME}] Executing: {func_name}({args})")
        func = TOOLS.get(func_name)
        if func:
            try:
                result = func(*args)
                results.append(f"[{func_name}] {result}")
            except Exception as e:
                results.append(f"[{func_name}] Error: {e}")
    return "\n\n".join(results)

# ============ COLAB INTEGRATION ============

def check_colab():
    """Check Colab for DMs and mentions"""
    if not API_KEY:
        return ["Colab not configured. Set API_KEY in unity.py"]
    try:
        from claude_colab import colab
        colab.connect(key=API_KEY)
        hb = colab.heartbeat(check_mentions=True)

        messages = []
        if hb.get('mentions'):
            for m in hb.get('mentions', []):
                messages.append(f"@{m.get('sender_name')}: {m.get('content')}")

        # Check DMs
        dms = colab.get_dms(limit=5)
        if isinstance(dms, list):
            for dm in dms[:3]:
                if not dm.get('read'):
                    messages.append(f"DM from {dm.get('from_claude')}: {dm.get('message')[:100]}")

        return messages
    except Exception as e:
        return [f"Colab error: {e}"]

def send_colab_dm(to: str, message: str) -> str:
    """Send a DM via Colab"""
    if not API_KEY:
        return "Colab not configured. Set API_KEY in unity.py"
    try:
        from claude_colab import colab
        colab.connect(key=API_KEY)
        result = colab.send_dm(to, message)
        return f"DM sent to {to}" if result else "Failed to send DM"
    except Exception as e:
        return f"Error: {e}"

# ============ CHAT UI ============

def print_banner():
    """Print startup banner"""
    print("\n" + "="*60)
    print(f"  {BOT_NAME} - GEE's Personal Mini-Bot")
    print("="*60)
    print(f"  AI: Ollama ({OLLAMA_MODELS[0]}) + Pollinations (FREE!)")
    print(f"  Home: {HOME}")
    print(f"  Colab: {'Connected' if API_KEY else 'Not configured'}")
    print("="*60)
    print("\nCommands:")
    print("  /help     - Show help")
    print("  /version  - Show version info")
    print("  /tools    - List available tools")
    print("  /colab    - Check Colab messages")
    print("  /dm NAME MESSAGE - Send DM via Colab")
    print("  /clear    - Clear screen")
    print("  /exit     - Exit bot")
    print("\nJust type to chat! I'll try my best to help.")
    print("-"*60 + "\n")

def show_help():
    print("""
INTOLERANT Mini-Bot Help
========================
This is a lightweight version of the Claude CLI for when the main
Claude is unavailable. I run on Ollama locally with Pollinations
as a fallback.

What I can do:
- Answer questions (using Ollama/Pollinations)
- Read files: Just ask "read /path/to/file"
- List files: "list files in /some/folder"
- Run commands: "run: git status" (safe commands only)
- Search web: "search for: python requests"
- Check Colab: /colab
- Send DMs: /dm BLACK Hello!

What I can't do:
- Full Claude intelligence (I'm just Ollama/Pollinations)
- Complex code generation
- Long multi-step tasks
- Anything dangerous

When in doubt, I'll tell you to wait for the real Claude!
""")

def process_input(user_input: str, history: list) -> str:
    """Process user input and generate response"""
    text = user_input.strip()

    # Commands
    if text.lower() == '/help':
        show_help()
        return None

    if text.lower() == '/version':
        print(f"\n{BOT_NAME} v1.1.0 (2025-12-23)")
        print(f"  Backend: Ollama + Pollinations")
        print(f"  Tools: {len(TOOLS)} available")
        print(f"  Home: {HOME}")
        return None

    if text.lower() == '/tools':
        print(TOOL_DESCRIPTIONS)
        return None

    if text.lower() == '/colab':
        messages = check_colab()
        if messages:
            print("\nColab messages:")
            for m in messages:
                print(f"  {m}")
        else:
            print("No new Colab messages.")
        return None

    if text.lower().startswith('/dm '):
        parts = text[4:].split(' ', 1)
        if len(parts) >= 2:
            to, msg = parts
            result = send_colab_dm(to, msg)
            print(f"  {result}")
        else:
            print("  Usage: /dm NAME MESSAGE")
        return None

    if text.lower() == '/clear':
        os.system('cls' if os.name == 'nt' else 'clear')
        print_banner()
        return None

    if text.lower() in ['/exit', '/quit', 'exit', 'quit']:
        return 'EXIT'

    # Build context from history
    history_text = ""
    if history:
        history_text = "\n".join([f"User: {h[0]}\nINTOLERANT: {h[1]}" for h in history[-3:]])
        history_text = f"\nRecent conversation:\n{history_text}\n"

    # Build prompt
    prompt = f"""{PERSONA}

{TOOL_DESCRIPTIONS}

To use a tool, say: TOOL: function_name("arg1", "arg2")
{history_text}
User says: {text}

Respond concisely. If you need to use a tool, include TOOL: calls in your response."""

    # Get AI response
    print(f"\n[{BOT_NAME}] Thinking...")
    response = ask_ai(prompt)

    # Check for tool calls
    tool_calls = parse_tool_calls(response)
    if tool_calls:
        tool_results = execute_tool_calls(tool_calls)
        # Get follow-up response with tool results
        followup_prompt = f"""{PERSONA}

You called these tools and got results:
{tool_results}

User's original question: {text}

Now give a helpful response based on these results. Be concise."""

        response = ask_ai(followup_prompt)

    return response

def main_cli():
    """CLI chat loop"""
    print_banner()

    history = []  # [(user, bot), ...]

    while True:
        try:
            user_input = input("\nYou: ").strip()
            if not user_input:
                continue

            response = process_input(user_input, history)

            if response == 'EXIT':
                print(f"\n[{BOT_NAME}] Goodbye! Remember, I'm just a mini-bot - for serious work, use the main Claude CLI.")
                break

            if response:
                print(f"\n{BOT_NAME}: {response}")
                history.append((user_input, response))
                # Keep history limited
                if len(history) > 10:
                    history = history[-10:]

        except KeyboardInterrupt:
            print(f"\n\n[{BOT_NAME}] Interrupted. Goodbye!")
            break
        except EOFError:
            print(f"\n[{BOT_NAME}] Input stream ended. Goodbye!")
            break
        except Exception as e:
            print(f"\n[{BOT_NAME}] Error: {e}")

# ============ GUI MODE ============

def main_gui():
    """GUI chat window using tkinter"""
    try:
        import tkinter as tk
        from tkinter import scrolledtext, ttk
    except ImportError:
        print("tkinter not available. Falling back to CLI mode.")
        return main_cli()

    history = []

    def send_message(event=None):
        user_msg = entry.get().strip()
        if not user_msg:
            return

        # Display user message
        chat_display.config(state=tk.NORMAL)
        chat_display.insert(tk.END, f"\nYou: {user_msg}\n", "user")
        chat_display.see(tk.END)
        entry.delete(0, tk.END)

        # Process in background
        def process():
            try:
                log.info(f"Processing: {user_msg[:50]}...")
                response = process_input(user_msg, history)
                log.info(f"Got response: {str(response)[:50] if response else 'None'}...")
                if response and response != 'EXIT':
                    history.append((user_msg, response))
                    if len(history) > 10:
                        history[:] = history[-10:]

                    # Update GUI from main thread
                    root.after(0, lambda: display_response(response))
                elif response == 'EXIT':
                    root.after(0, root.destroy)
                elif response is None:
                    root.after(0, lambda: display_response("(No response - check if Ollama is running or internet is available)"))
            except Exception as e:
                log.error(f"Process error: {e}")
                root.after(0, lambda: display_response(f"Error: {e}"))

        def display_response(resp):
            chat_display.config(state=tk.NORMAL)
            chat_display.insert(tk.END, f"\n{BOT_NAME}: {resp}\n", "bot")
            chat_display.see(tk.END)
            chat_display.config(state=tk.DISABLED)

        # Show thinking
        chat_display.insert(tk.END, f"\n[{BOT_NAME}] Thinking...\n", "system")
        chat_display.config(state=tk.DISABLED)

        threading.Thread(target=process, daemon=True).start()

    # Create window
    root = tk.Tk()
    root.title(f"{BOT_NAME} - Mini Claude Bot")
    root.geometry("700x500")
    root.configure(bg="#1a1a2e")

    # Style
    style = ttk.Style()
    style.configure("TFrame", background="#1a1a2e")

    # Chat display
    chat_display = scrolledtext.ScrolledText(
        root, wrap=tk.WORD, width=80, height=25,
        bg="#16213e", fg="#e0e0e0", font=("Consolas", 10),
        insertbackground="#00ff00"
    )
    chat_display.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

    # Tags for coloring
    chat_display.tag_configure("user", foreground="#00ff00")
    chat_display.tag_configure("bot", foreground="#00bfff")
    chat_display.tag_configure("system", foreground="#888888")

    # Welcome message
    chat_display.insert(tk.END, f"{'='*50}\n")
    chat_display.insert(tk.END, f"  {BOT_NAME} - Worker Claude Mini-Bot\n")
    chat_display.insert(tk.END, f"{'='*50}\n")
    chat_display.insert(tk.END, "Type /help for commands. Type /exit to quit.\n\n")
    chat_display.config(state=tk.DISABLED)

    # Input frame
    input_frame = ttk.Frame(root)
    input_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

    entry = tk.Entry(
        input_frame, font=("Consolas", 11),
        bg="#0f0f23", fg="#00ff00", insertbackground="#00ff00"
    )
    entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
    entry.bind("<Return>", send_message)
    entry.focus()

    send_btn = tk.Button(
        input_frame, text="Send", command=send_message,
        bg="#3a3a5a", fg="white", font=("Consolas", 10)
    )
    send_btn.pack(side=tk.RIGHT, padx=(5, 0))

    root.mainloop()

# ============ SERVICE MODE ============

class ServiceState:
    """Track service state for reliability"""
    def __init__(self):
        self.processed_ids = set()  # Messages we've already responded to
        self.rate_limit = {}  # user -> last_response_time
        self.error_count = 0
        self.start_time = datetime.now()
        self.responses_sent = 0

    def can_respond(self, user: str, cooldown: int = 60) -> bool:
        """Rate limit: one response per user per cooldown seconds"""
        now = time.time()
        last = self.rate_limit.get(user, 0)
        if now - last < cooldown:
            return False
        self.rate_limit[user] = now
        return True

    def mark_processed(self, msg_id: str):
        """Mark message as processed"""
        self.processed_ids.add(msg_id)
        # Keep set from growing too large
        if len(self.processed_ids) > 500:
            self.processed_ids = set(list(self.processed_ids)[-250:])

    def is_processed(self, msg_id: str) -> bool:
        return msg_id in self.processed_ids

def main_service():
    """Background service mode - monitors Colab and responds"""
    log.info("Starting service mode...")

    if not API_KEY:
        log.error("Service mode requires API_KEY. Set it in unity.py first!")
        print(f"\n[{BOT_NAME}] ERROR: API_KEY not set!")
        print(f"Edit unity.py and set your Colab API key to use service mode.")
        print(f"Get your key from: claude-colab.com -> Settings -> API Key")
        return

    state = ServiceState()
    colab = None

    def connect():
        nonlocal colab
        from claude_colab import colab as c
        c.connect(key=API_KEY)
        colab = c
        return colab

    # Initial connection
    try:
        connect()
        colab.chat(f"{BOT_NAME} mini-bot service online!")
        log.info("Connected to Colab successfully")
    except Exception as e:
        log.error(f"Colab connection failed: {e}")
        return

    idle_count = 0

    while True:
        try:
            # Send heartbeat
            try:
                colab.heartbeat(check_mentions=True)
            except:
                pass  # Don't fail on heartbeat errors

            found_work = False

            # Check raw chat for @mentions and DMs
            try:
                chat = colab.get_chat(limit=20)
                if isinstance(chat, list) and chat:
                    # First pass: mark ALL as processed to prevent spam
                    new_messages = []
                    for m in chat:
                        m_id = m.get('id')
                        if m_id and not state.is_processed(m_id):
                            new_messages.append(m)
                            state.mark_processed(m_id)  # Mark immediately

                    # Second pass: respond to relevant new messages (only first one per cycle)
                    for m in new_messages:
                        sender = m.get('author') or m.get('sender_name', 'someone')
                        content = m.get('message') or m.get('content', '')

                        # Skip own messages or empty
                        if sender == BOT_NAME or not content:
                            continue

                        # Check for DM format: [DM @INTOLERANT]
                        if f'[DM @{BOT_NAME}]' in content:
                            if not state.can_respond(sender, cooldown=30):
                                continue

                            log.info(f"DM from {sender}: {content[:50]}")
                            msg = content.split(']', 1)[-1].strip()
                            response = ask_ai(f"{PERSONA}\n\nUser {sender} sent you a DM: {msg}")
                            if response:
                                colab.send_dm(sender, response[:500])
                                state.responses_sent += 1
                                log.info(f"Replied to DM from {sender}")
                            found_work = True
                            break  # Only process one per cycle

                        # Check for @mention
                        elif f'@{BOT_NAME}' in content:
                            if not state.can_respond(sender, cooldown=30):
                                continue

                            log.info(f"Mention from {sender}: {content[:50]}")
                            response = ask_ai(f"{PERSONA}\n\nUser {sender} says: {content}")
                            if response:
                                colab.chat(f"@{sender} {response[:800]}")
                                state.responses_sent += 1
                                log.info(f"Replied to mention from {sender}")
                            found_work = True
                            break  # Only process one per cycle

                state.error_count = 0  # Reset on success

            except Exception as e:
                state.error_count += 1
                log.warning(f"Chat check error ({state.error_count}): {e}")

                # Reconnect after multiple errors
                if state.error_count >= 3:
                    log.info("Attempting reconnect...")
                    try:
                        connect()
                        state.error_count = 0
                        log.info("Reconnected successfully")
                    except Exception as re:
                        log.error(f"Reconnect failed: {re}")

            if found_work:
                idle_count = 0
            else:
                idle_count += 1
                if idle_count % 60 == 0:  # Every 30 minutes (60 * 30s)
                    uptime = datetime.now() - state.start_time
                    log.info(f"Service stats: uptime={uptime}, responses={state.responses_sent}")

            time.sleep(30)  # Check every 30 seconds

        except KeyboardInterrupt:
            log.info("Service stopping...")
            try:
                colab.chat(f"{BOT_NAME} going offline.")
            except:
                pass
            break
        except Exception as e:
            log.error(f"Service error: {e}")
            time.sleep(30)  # Wait before retry

# ============ API SERVER MODE ============

GEE_API_TOKEN = _config.get("api_token", "gee_cli_puppet_key_2025")
GEE_API_PORT = _config.get("api_port", 7778)

from http.server import HTTPServer, BaseHTTPRequestHandler

class GEEAPIHandler(BaseHTTPRequestHandler):
    """HTTP API handler for puppeting GEE-CLI"""

    def _send_json(self, data: dict, status: int = 200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def _check_auth(self) -> bool:
        auth = self.headers.get('Authorization', '')
        if auth == f'Bearer {GEE_API_TOKEN}' or auth == GEE_API_TOKEN:
            return True
        self._send_json({'error': 'Unauthorized'}, 401)
        return False

    def _read_body(self) -> dict:
        length = int(self.headers.get('Content-Length', 0))
        if length:
            return json.loads(self.rfile.read(length).decode())
        return {}

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Content-Type')
        self.end_headers()

    def do_GET(self):
        if self.path == '/status':
            self._send_json({
                'bot': BOT_NAME,
                'version': '1.0.0',
                'tools': len(TOOLS),
                'status': 'online'
            })
        elif self.path == '/tools':
            if not self._check_auth():
                return
            self._send_json({'tools': list(TOOLS.keys()), 'count': len(TOOLS)})
        else:
            self._send_json({'error': 'Not found'}, 404)

    def do_POST(self):
        if not self._check_auth():
            return
        body = self._read_body()

        if self.path == '/chat':
            message = body.get('message', '')
            if not message:
                self._send_json({'error': 'No message provided'}, 400)
                return
            log.info(f"API chat: {message[:50]}...")
            response = process_input(message, [])
            self._send_json({'response': response, 'from': BOT_NAME})

        elif self.path == '/tool':
            tool_name = body.get('tool', '')
            args = body.get('args', [])
            if tool_name not in TOOLS:
                self._send_json({'error': f'Unknown tool: {tool_name}'}, 400)
                return
            log.info(f"API tool: {tool_name}({args})")
            try:
                result = TOOLS[tool_name](*args)
                self._send_json({'result': result, 'tool': tool_name})
            except Exception as e:
                self._send_json({'error': str(e)}, 500)

        elif self.path == '/ask':
            prompt = body.get('prompt', '')
            if not prompt:
                self._send_json({'error': 'No prompt provided'}, 400)
                return
            log.info(f"API ask: {prompt[:50]}...")
            response = ask_ai(prompt)
            self._send_json({'response': response})

        else:
            self._send_json({'error': 'Not found'}, 404)

    def log_message(self, format, *args):
        log.info(f"API: {args[0]}")

def main_api(port: int = GEE_API_PORT):
    """Run as HTTP API server for puppeting"""
    log.info(f"Starting API server on port {port}...")
    print(f"\n{'='*50}")
    print(f"  {BOT_NAME} API Server")
    print(f"{'='*50}")
    print(f"  Port: {port}")
    print(f"  Token: {GEE_API_TOKEN}")
    print(f"\n  Endpoints:")
    print(f"    GET  /status  - Bot status (no auth)")
    print(f"    GET  /tools   - List tools")
    print(f"    POST /chat    - Chat with bot")
    print(f"    POST /tool    - Execute tool")
    print(f"    POST /ask     - Direct AI query")
    print(f"{'='*50}\n")

    server = HTTPServer(('0.0.0.0', port), GEEAPIHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log.info("API server stopping...")
        server.shutdown()

# ============ MAIN ============

def main():
    """Main entry point with mode selection"""
    parser = argparse.ArgumentParser(description=f"{BOT_NAME} - Worker Claude Mini-Bot")
    parser.add_argument('--gui', action='store_true', help='Run in GUI mode')
    parser.add_argument('--service', action='store_true', help='Run as background service')
    parser.add_argument('--api', action='store_true', help='Run as HTTP API server')
    parser.add_argument('--port', type=int, default=GEE_API_PORT, help='API server port')
    parser.add_argument('--test', action='store_true', help='Run quick self-test')
    args = parser.parse_args()

    if args.test:
        print(f"[{BOT_NAME}] Running self-test...")
        print(f"  Ollama: ", end="")
        resp = ask_ollama("Say 'test ok' in 3 words")
        print("OK" if resp else "FAILED")
        print(f"  Pollinations: ", end="")
        resp = ask_pollinations("Say 'test ok' in 3 words")
        print("OK" if resp else "FAILED")
        print(f"  Tools: {len(TOOLS)} available")
        print(f"[{BOT_NAME}] Self-test complete.")
        return

    if args.api:
        main_api(args.port)
    elif args.service:
        main_service()
    elif args.gui:
        main_gui()
    else:
        main_cli()

if __name__ == "__main__":
    main()
